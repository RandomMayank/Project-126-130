song1 = "";
song2 = "";

function preload() {
    song1 = loadSound("music.mp3");
    song2 = loadSound("music2.mp3")
}

score_leftWrist = 0;
score_rightWrist = 0;

leftWrist_x = 0;
leftWrist_y = 0;

rightWrist_x = 0;
rightWrist_y = 0;

song1_status = "";
song2_status = "";

function setup() {
    canvas = createCanvas(600, 500);
    canvas.center();

    video = createCapture(VIDEO);
    video.hide();

    posenet = poseNet(video, modelLoaded);
    posenet.on("pose", gotPoses)
}

function modelLoaded() {
    console.log("Model has been successfully loaded.")
}

function gotPoses(results) { // Result is an array that loads all the body parts.
    if (results.length > 0) {
        console.log(results)

        score_leftWrist = results[0].pose.keypoints[9].score
        score_rightWrist = results[0].pose.keypoints[10].score

        rightWrist_x = results[0].pose.rightWrist.x
        rightWrist_y = results[0].pose.rightWrist.y

        leftWrist_x = results[0].pose.leftWrist.x
        leftWrist_y = results[0].pose.leftWrist.y
        
    }
}

function draw() {
    image(video, 0, 0, 600, 500);
    song1_status = song1.isPlaying();
    song2_status = song2.isPlaying();
    fill("red");
    stroke("red");

    if(score_rightWrist > 0.2)
    {
        circle(rightWrist_x, rightWrist_y, 20)

        song2.stop();
        if(song1_status == false){
            song1.play();
            document.getElementById("song").innerHTML = "Song 1 is playing."
        }
    }

    if(score_leftWrist > 0.2)
    {
        circle(leftWrist_x, leftWrist_y, 20)
         
        song1.stop();
        if(song2_status == false){
            song2.play();
            document.getElementById("song").innerHTML = "Song 2 is playing."
        }
        }
    }


function play() { //this function was called in HTML and made in java script.
    song.play(); //this function is a pre-made function from p5.js editor used to play sounds.
    song.setVolume(1); //setVolume helps set up the volume between 0 to 1.
    song.rate(1); //rate helps set the speed of the song 1-Normal , Less than 1 - Slowed Down, More than 1 - Sped Up
}